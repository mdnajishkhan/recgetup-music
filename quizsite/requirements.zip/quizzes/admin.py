from django.contrib import admin
from .models import Quiz, Question, Choice, Attempt, Answer, QuizAccessGrant, Profile, College, Category
from django.urls import path
from django.shortcuts import render, redirect
from django.contrib import messages
import pandas as pd
from .forms import QuestionImportForm


from nested_admin import NestedModelAdmin, NestedTabularInline, NestedStackedInline

class ChoiceInline(NestedTabularInline):
    model = Choice
    extra = 2


class QuestionAdmin(admin.ModelAdmin):
    inlines = [ChoiceInline]
    list_display = ('quiz', 'short_text')

    def short_text(self, obj):
        return obj.text[:60]


class QuestionInline(NestedStackedInline):
    model = Question
    extra = 1
    inlines = [ChoiceInline]

@admin.register(Quiz)
class QuizAdmin(NestedModelAdmin):
    list_display = ('title', 'category', 'quiz_type', 'difficulty', 'is_active', 'coupon_code')
    list_filter = ('category', 'quiz_type', 'difficulty', 'is_active')
    search_fields = ('title', 'coupon_code')
    ordering = ('-id',)
    list_editable = ('is_active',)
    inlines = [QuestionInline]
    fieldsets = (
        ('Quiz Info', {'fields': ('title', 'description', 'category', 'quiz_type', 'difficulty', 'duration_minutes', 'passing_percentage', 'is_active')}),
        ('Access Control', {'fields': ('coupon_code',)}),
    )
    change_form_template = 'admin/quizzes/quiz/change_form.html'

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path(
                '<int:object_id>/import-questions/',
                self.admin_site.admin_view(self.import_questions),
                name='quiz-import-questions',
            ),
        ]
        return custom_urls + urls

    def import_questions(self, request, object_id):
        quiz = self.get_object(request, object_id)
        if request.method == 'POST':
            form = QuestionImportForm(request.POST, request.FILES)
            if form.is_valid():
                file = request.FILES['file']
                try:
                    if file.name.endswith('.csv'):
                        df = pd.read_csv(file)
                    else:
                        df = pd.read_excel(file)
                    
                    # Expected columns: Question, Option A, Option B, Option C, Option D, Correct Answer
                    # Normalize headers
                    df.columns = [c.strip() for c in df.columns]
                    
                    count = 0
                    for index, row in df.iterrows():
                        question_text = row.get('Question')
                        if not question_text:
                            continue
                        
                        # Create Question
                        question = Question.objects.create(quiz=quiz, text=question_text)
                        
                        # Options
                        options = {
                            'A': row.get('Option A'),
                            'B': row.get('Option B'),
                            'C': row.get('Option C'),
                            'D': row.get('Option D')
                        }
                        
                        correct_ans = str(row.get('Correct Answer')).strip().upper()
                        
                        for key, text in options.items():
                            if pd.isna(text):
                                continue
                            
                            is_correct = False
                            # Check if correct answer matches the option key (A, B, C, D) or the text itself
                            if correct_ans == key:
                                is_correct = True
                            elif correct_ans == str(text).strip().upper():
                                is_correct = True
                                
                            Choice.objects.create(
                                question=question,
                                text=text,
                                is_correct=is_correct
                            )
                        count += 1
                    
                    messages.success(request, f"Successfully imported {count} questions.")
                    return redirect('admin:quizzes_quiz_change', object_id)
                    
                except Exception as e:
                    messages.error(request, f"Error importing file: {e}")
        else:
            form = QuestionImportForm()

        context = {
            'form': form,
            'object': quiz,
            'opts': self.model._meta,
            'object_id': object_id,
            'title': f'Import Questions for {quiz.title}'
        }
        return render(request, 'admin/quizzes/quiz/import_questions.html', context)


admin.site.register(Question, QuestionAdmin)
@admin.register(Attempt)
class AttemptAdmin(admin.ModelAdmin):
    list_display = ('user', 'get_college_name', 'quiz', 'score', 'passed', 'finished_at')
    list_filter = ('quiz', 'passed', 'finished_at', 'user__profile__college')
    date_hierarchy = 'finished_at'
    ordering = ('-score', 'finished_at')

    def get_college_name(self, obj):
        if hasattr(obj.user, 'profile') and obj.user.profile.college:
            return obj.user.profile.college.name
        return "-"
    get_college_name.short_description = 'College'
admin.site.register(QuizAccessGrant)
admin.site.register(Profile)
admin.site.register(College)
admin.site.register(Category)
