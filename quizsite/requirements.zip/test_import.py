try:
    import nested_admin
    print("nested_admin is installed and importable.")
except ImportError as e:
    print(f"Error importing nested_admin: {e}")
